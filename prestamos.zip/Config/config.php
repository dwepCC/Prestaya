<?php
    define("HOST",'locaLhost');
    define("DB_USER",'root');
    define("DB_PASS",'');
    define("DB_NAME",'prestacenter');

    define("PORT",3306);
    define("CHARSET",'utf8');
    //define("UNIX_SOCKET",'/var/run/mysql/mysql.sock');
    define("SYSTEMNAME","PrestaYa");


