    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <!-- add content here -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4>Sin acceso</h4>
                            </div>
                            <div class="card-body">
                                Lo siento...! no tiene acceso a este sitio
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>